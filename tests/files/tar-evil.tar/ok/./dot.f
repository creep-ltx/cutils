ok/./dot.f
