ok//twice.f
