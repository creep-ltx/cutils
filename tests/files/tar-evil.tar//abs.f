/abs.f
